package tv.own.owntv.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.koin.compose.koinInject
import tv.own.owntv.core.menu.applyMenuOrder
import tv.own.owntv.core.model.ContentMenu
import tv.own.owntv.core.settings.SettingsRepository

/**
 * One action in a long-press content menu — Live channel, movie, series or episode.
 *
 * The four menus used to be hand-written columns of buttons wrapped in `if`s, which meant their order
 * was the source order and nothing could be rearranged. They now build a list of these instead, and
 * render it in list order, so a later release can sort that list without touching any menu.
 *
 * [key] is a stable identifier and is deliberately NOT derived from the label: labels are translated,
 * and several of them toggle between two texts ("Add to favourites" / "Remove from favourites").
 *
 * [group] only spaces the menu out: a divider (or a gap, depending on the menu) is drawn wherever the
 * group changes between two neighbouring actions. An empty group simply produces no divider.
 */
data class MenuAction(
    val key: String,
    val label: String,
    val icon: OwnTVIcon? = null,
    val destructive: Boolean = false,
    val group: Int = 0,
    val onClick: () -> Unit,
)

/**
 * [actions] in the order the user arranged [menu] into. The menus read the setting themselves rather
 * than have it threaded down through four screens and their view models.
 *
 * The ordering rule itself is core's, so both apps arrange the same saved keys the same way.
 */
@Composable
fun arranged(menu: ContentMenu, actions: List<MenuAction>): List<MenuAction> {
    val settings: SettingsRepository = koinInject()
    val order by remember(menu) { settings.menuOrder(menu.name.lowercase()) }
        .collectAsStateWithLifecycle(emptyList())
    return applyMenuOrder(actions, order) { it.key }
}
