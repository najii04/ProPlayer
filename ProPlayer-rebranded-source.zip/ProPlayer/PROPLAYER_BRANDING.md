# Pro Player branding notes

This repository is a branded fork of OwnTV by ahXN00, distributed under the original GPL-3.0 license.
The upstream `LICENSE` file and original attribution are retained.

Branding changes in this fork:
- Display name: Pro Player
- Android application ID: `com.promaxsat.proplayer`
- Launcher icon and Android TV banner: Pro Player assets in `app/src/main/res/drawable-nodpi/`
- In-app wordmark: Pro Player
- About-page repository label: `github.com/najii04/ProPlayer`
- CI release asset name: `ProPlayer.apk`

The Kotlin/Gradle namespace remains `tv.own.owntv` to avoid breaking generated `R` references and internal code.
The About page Telegram link and QR now point to https://t.me/promaxsatdz.
This archive has not been built or run on a device in this environment.
